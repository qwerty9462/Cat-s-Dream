﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public Rigidbody2D rb;
    public Animator anim;
    public Collider2D coll;
    [Space]
    public float speed;
    public LayerMask ground;

    //触碰怪物弹回
    public bool isHurt; //默认值为false

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (!isHurt)
        {
           Movement();
        }
        //SwitchAnim();
    }

    void Movement()
    {
        float horizontalmove;
        float verticalmove;
        horizontalmove = Input.GetAxis("Horizontal");
        verticalmove = Input.GetAxis("Vertical");

        //角色移动
        if (horizontalmove != 0)
        {
            rb.velocity = new Vector2(horizontalmove * speed * Time.deltaTime, rb.velocity.y);
        }

        if (verticalmove != 0)
        {
            rb.velocity = new Vector2(verticalmove * speed * Time.deltaTime, rb.velocity.x);
        }
    }

    //切换动画效果
    void SwitchAnim()
    {
        //anim.SetBool("idle", false);

       // if (anim.GetBool("jumping"))
       // {
           // if (rb.velocity.y < 0)
           // {
                //anim.SetBool("jumping", false);
              //  anim.SetBool("falling", true);
           // }
       // }
       // else 
        if (isHurt)
        {
            anim.SetBool("hurt", true);
            if (Mathf.Abs(rb.velocity.x) < 0.1f)
            {
                 //anim.SetBool("falling", false);
                // anim.SetBool("idle", true);
                isHurt = false;
            }

        }
       // else if (coll.IsTouchingLayers(ground))
       // {
           // anim.SetBool("falling", false); //跳跃
           // anim.SetBool("idle", true); //站立
       // }
    }

    //碰撞敌人
    private void OnCollisionEnter2D(Collision2D collision) 
    {
        //在怪物左边
        if (transform.position.x < collision.gameObject.transform.position.x)
        {
            rb.velocity = new Vector2(-10, rb.velocity.y);
            isHurt = true;
        }
        //在怪物右边
        if (transform.position.x > collision.gameObject.transform.position.x)
        {
            rb.velocity = new Vector2(10, rb.velocity.y);
            isHurt = true;
        }
    }
    //消灭敌人
    //private void OnCollisionEnter2D(Collision2D collision)
    //{
    //  if (anim.GetBool("falling"))
    //  if (collision.gameObject.tag == "Enemy") 
    //{
    //  Destroy(collision.gameObject);
    //}
    //





}


