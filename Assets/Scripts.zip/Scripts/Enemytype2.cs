﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemytype2 : MonoBehaviour
{
    public static Enemy instance;
    Animator ani;
    Transform player_Pos;
    bool IsCanMove = true;
    float time = 0;//记录怪物几秒后可以行动
    void Awake()
    {
        ani = transform.GetComponent<Animator>();
    }
    // Use this for initialization
    void Start()
    {
        player_Pos = GameObject.Find("Canvas").transform.Find("Player").Find("Player");
    }

    // Update is called once per frame
    void Update()
    {
        if (time > 1)
        {
            Move();
        }
        else
        {
            time += Time.deltaTime;
        }
    }

    void Move()
    {
        if (IsCanMove)
        {
            float dis = Vector2.Distance(transform.position, player_Pos.position);
            transform.position = Vector2.Lerp(transform.position, player_Pos.position, Time.deltaTime * (1 / dis) * 2);
        }
    }

    /// <summary>
    /// 怪物碰撞到玩家
    /// </summary>
    /// <param name="c"></param>
    void OnTriggerEnter2D(Collider2D c)
    {
        if (c.transform.tag == "Enemy")
        {
           
            transform.GetComponent<BoxCollider2D>().enabled = false;
            ani.SetBool("IsDeath", true);
           
        }
    }

    /// <summary>
    /// 动画帧事件调用，怪物死亡后不能移动
    /// </summary>
    void NotMove()
    {
        IsCanMove = false;
        transform.GetComponent<BoxCollider2D>().enabled = false;
    }

    /// <summary>
    /// 动画帧事件调用，怪物死亡后销毁自己
    /// </summary>
    void DestroySelf()
    {
        
        Destroy(transform.gameObject);
    }

    /// <summary>
    /// 动画帧事件调用，显示怪物自己的collider
    /// </summary>
    void Show_collider()
    {
        transform.GetComponent<BoxCollider2D>().enabled = true;
    }
}
