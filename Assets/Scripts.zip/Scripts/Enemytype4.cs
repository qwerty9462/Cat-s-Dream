﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemytype4 : MonoBehaviour
{
    bool IsCanMove = true;
    Vector2 forward_move;
    Animator ani;

    // Use this for initialization
    void Start()
    {
        forward_move = Random.insideUnitCircle.normalized * 0.5f;

    }

    // Update is called once per frame
    void Update()
    {
        if (IsCanMove)
        {
            Move();
        }

    }

    void Move()
    {
        transform.Translate(forward_move * Time.deltaTime * 5);

    }

    //敌人撞到墙上行动方向进行反弹
    void OnCollisionStay2D(Collision2D c)
    {
        #region 说明敌人位移方向在第一象限,反弹情况有两种
        if (forward_move.x > 0 && forward_move.y > 0)
        {
            //如果撞到右墙,方向是x轴正负相反，y不变
            if (c.transform.name == "wall_r_u" || c.transform.name == "wall_r_d" || c.transform.name == "door_right")
            {
                forward_move = new Vector2(-forward_move.x, forward_move.y);
            }
            //如果撞到上墙，是y轴正负相反，x轴不变
            else if (c.transform.name == "wall_u_r" || c.transform.name == "wall_u_l" || c.transform.name == "door_up")
            {
                forward_move = new Vector2(forward_move.x, -forward_move.y);
            }
        }
        #endregion

        #region 说明敌人的位移方向在第二象限，反弹情况有两种
        else if (forward_move.x < 0 && forward_move.y > 0)
        {
            //如果撞到上墙，X不变，Y相反
            if (c.transform.name == "wall_u_r" || c.transform.name == "wall_u_l" || c.transform.name == "door_up")
            {
                forward_move = new Vector2(forward_move.x, -forward_move.y);
            }
            //如果撞到左墙，Y不变，X相反
            else if (c.transform.name == "wall_l_u" || c.transform.name == "wall_l_d" || c.transform.name == "door_right")
            {
                forward_move = new Vector2(-forward_move.x, forward_move.y);
            }
        }
        #endregion

        #region 说明敌人的位移方向在第三象限，反弹情况有两种
        if (forward_move.x < 0 && forward_move.y < 0)
        {
            //弹到下墙，X不变，Y相反
            if (c.transform.name == "wall_d_r" || c.transform.name == "wall_d_l" || c.transform.name == "door_down")
            {
                forward_move = new Vector2(forward_move.x, -forward_move.y);
            }
            //弹到左墙，Y不变，X相反
            else if (c.transform.name == "wall_l_u" || c.transform.name == "wall_l_d" || c.transform.name == "door_left")
            {
                forward_move = new Vector2(-forward_move.x, forward_move.y);
            }
        }
        #endregion

        #region 说明敌人位移方向在第四象限，反弹情况有两种
        else if (forward_move.x > 0 && forward_move.y < 0)
        {
            //如果撞到下墙上面，X轴不变，Y相反
            if (c.transform.name == "wall_d_r" || c.transform.name == "wall_d_l" || c.transform.name == "door_down")
            {
                forward_move = new Vector2(forward_move.x, -forward_move.y);
            }
            //如果撞到右墙上面，Y不变，X相反
            else if (c.transform.name == "wall_r_u" || c.transform.name == "wall_r_d" || c.transform.name == "door_right")
            {
                forward_move = new Vector2(-forward_move.x, forward_move.y);
            }
        }
        #endregion
    }



    //攻击动画结束,动画帧事件调用






    /// <summary>
    /// 怪物碰到玩家后检测碰撞
    /// </summary>
    /// <param name="c"></param>
    void OnTriggerEnter2D(Collider2D c)
    {
        if (c.transform.tag == "Enemy")
        {
            {
                transform.GetComponent<CircleCollider2D>().enabled = false;
                ani.SetBool("IsDeath", true);
            }
        }
    }

    /// <summary>
    /// 怪物死亡后，collider消失
    /// </summary>
    void Disapper_Collider()
    {
        transform.GetComponent<CircleCollider2D>().enabled = false;
    }

    /// <summary>
    /// 动画帧调用，死亡动画完了调用
    /// </summary>
    void DestroySelf()
    {


        Destroy(transform.gameObject);
    }

    /// <summary>
    /// 动画帧调用，怪物死后停止移动
    /// </summary>
    void IsNotCanMove()
    {
        IsCanMove = false;
    }
}
